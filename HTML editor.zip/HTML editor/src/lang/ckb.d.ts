import { Lang } from './Lang';

declare const ckb: Lang;

export default ckb;