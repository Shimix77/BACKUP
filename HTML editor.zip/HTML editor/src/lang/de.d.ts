import { Lang } from './Lang';

declare const de: Lang;

export default de;