import { Lang } from './Lang';

declare const pl: Lang;

export default pl;