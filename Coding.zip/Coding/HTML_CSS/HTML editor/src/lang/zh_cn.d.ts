import { Lang } from './Lang';

declare const zhCn: Lang;

export default zhCn;