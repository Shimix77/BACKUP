import { DialogPlugin } from '../DialogPlugin';

declare const mention: DialogPlugin;

export default mention;
